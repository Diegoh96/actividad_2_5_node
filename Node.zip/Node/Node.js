// Importar módulos
const mostrarVariables = require('./variables');
const validarAcceso = require('./condicionales');
const mostrarPares = require('./ciclos');
const { calcularIVA } = require('./funciones');
const manejarArchivos = require('./archivos');

console.log("===== ACTIVIDAD 2.5 NODE =====\n");

// Variables
mostrarVariables();

console.log("\n===== CONDICIONALES =====");
validarAcceso(20);

console.log("\n===== CICLOS =====");
mostrarPares();

console.log("\n===== FUNCIONES =====");

let precio = 10000;
let resultadoIVA = calcularIVA(precio);

console.log("Precio original:", precio);
console.log("Precio + IVA:", resultadoIVA);

console.log("\n===== ARCHIVOS FS =====");
manejarArchivos();
