const fs = require('fs');

function manejarArchivos() {

    let contenido = "Actividad Node.js completada correctamente";

    // Crear archivo
    fs.writeFileSync('resultados.txt', contenido);

    console.log("Archivo creado correctamente");

    // Leer archivo
    let lectura = fs.readFileSync('resultados.txt', 'utf8');

    console.log("Contenido del archivo:");
    console.log(lectura);

}

module.exports = manejarArchivos;