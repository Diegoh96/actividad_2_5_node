function mostrarVariables() {

    let nombre = "Diego";
    let edad = 22;
    let estudiante = true;
    let promedio = 5.8;

    console.log("===== VARIABLES Y TIPOS =====");

    console.log(nombre, "-", typeof nombre);
    console.log(edad, "-", typeof edad);
    console.log(estudiante, "-", typeof estudiante);
    console.log(promedio, "-", typeof promedio);

}

module.exports = mostrarVariables;