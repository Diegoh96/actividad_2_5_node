function validarAcceso(edad) {

    if (edad >= 18) {
        console.log("Acceso permitido");
    } else {
        console.log("Acceso denegado");
    }

}

module.exports = validarAcceso;