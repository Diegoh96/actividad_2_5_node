function calcularIVA(precio) {

    let iva = precio * 0.19;
    return precio + iva;

}

module.exports = {
    calcularIVA
};